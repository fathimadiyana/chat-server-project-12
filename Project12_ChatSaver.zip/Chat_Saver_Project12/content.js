(() => {
 if (window.__chatSaverLoaded) return; window.__chatSaverLoaded = true;
 const SITE = location.hostname.includes("gemini.google.com") ? "Gemini" : "ChatGPT";
 const STYLE_ID="chat-saver-style";
 const css=`
 #cs-panel{position:fixed;z-index:2147483647;right:18px;top:90px;width:350px;max-height:78vh;overflow:auto;background:#fff;color:#20283a;border:1px solid #dfe3ee;border-radius:15px;box-shadow:0 12px 45px #1113;font:13px system-ui,Arial;padding:14px}
 #cs-panel *{box-sizing:border-box}#cs-panel h3{margin:0;font-size:18px;color:#5144ad}#cs-panel .cs-muted{color:#68748b;font-size:11px;margin:4px 0 12px}
 #cs-panel button{border:0;border-radius:8px;padding:9px 11px;cursor:pointer;font-weight:650;background:#eeeafd;color:#4e43a7;margin:3px 2px}
 #cs-panel button.cs-primary{background:#6257c8;color:white}#cs-panel button.cs-close{float:right;background:#f2f3f7;color:#555}
 #cs-panel .cs-list{border:1px solid #e5e8f0;border-radius:9px;max-height:280px;overflow:auto;padding:5px}
 #cs-panel label{display:flex;gap:8px;padding:7px 3px;border-bottom:1px solid #f0f1f5;align-items:flex-start}
 #cs-panel label:last-child{border:0}#cs-panel input{margin-top:2px}#cs-panel .cs-actions{display:flex;flex-wrap:wrap;margin-top:10px}
 #cs-panel .cs-status{font-size:11px;color:#68748b;margin-top:8px;line-height:1.4}
 `;
 function cleanTitle(){return (document.title||"AI Chat").replace(/\s*[-|–].*$/,"").trim()||"AI Chat"}
 function findMessages(){
  let nodes=[];
  if(SITE==="ChatGPT"){
   nodes=[...document.querySelectorAll('[data-message-author-role="user"],[data-message-author-role="assistant"]')];
   if(!nodes.length) nodes=[...document.querySelectorAll('main article')];
  }else{
   nodes=[...document.querySelectorAll('user-query,model-response')];
   if(!nodes.length) nodes=[...document.querySelectorAll('main .conversation-container,main .message-content')];
  }
  nodes=[...new Set(nodes)].filter(n=>n.innerText?.trim() && !n.closest("#cs-panel"));
  return nodes;
 }
 function roleOf(n,i){
  let r=n.getAttribute("data-message-author-role");
  if(r)return r==="user"?"You":"Assistant";
  let tag=n.tagName.toLowerCase();
  if(tag==="user-query")return "You";
  if(tag==="model-response")return "Gemini";
  let label=(n.getAttribute("aria-label")||"").toLowerCase();
  return label.includes("user")?"You":(i%2===0?"You":"Assistant");
 }
 function inlineMarkdown(node){
  if(node.nodeType===Node.TEXT_NODE)return node.nodeValue.replace(/\s+/g," ");
  if(node.nodeType!==Node.ELEMENT_NODE)return "";
  const tag=node.tagName.toLowerCase();
  if(["button","svg","nav","textarea","input","script","style"].includes(tag))return "";
  if(tag==="br")return "\n";
  if(tag==="code" && node.parentElement?.tagName.toLowerCase()!=="pre")return "`"+node.textContent.replace(/`/g,"\\`")+"`";
  if(tag==="pre")return "\n```\n"+node.innerText.replace(/\n+$/,"")+"\n```\n";
  if(tag==="strong"||tag==="b")return "**"+[...node.childNodes].map(inlineMarkdown).join("")+"**";
  if(tag==="em"||tag==="i")return "*"+[...node.childNodes].map(inlineMarkdown).join("")+"*";
  if(tag==="a")return `[${[...node.childNodes].map(inlineMarkdown).join("").trim()||node.href}](${node.href})`;
  if(tag==="li")return "- "+[...node.childNodes].map(inlineMarkdown).join("").trim()+"\n";
  if(tag==="tr")return [...node.children].map(c=>inlineMarkdown(c).trim()).join(" | ")+"\n";
  if(tag==="th"||tag==="td")return [...node.childNodes].map(inlineMarkdown).join("").trim();
  let content=[...node.childNodes].map(inlineMarkdown).join("");
  if(/^h[1-6]$/.test(tag))return "\n"+"#".repeat(+tag[1])+" "+content.trim()+"\n\n";
  if(tag==="p"||tag==="div"||tag==="section")return content.trim()?"\n"+content.trim()+"\n":"";
  if(tag==="ul"||tag==="ol")return "\n"+content+"\n";
  if(tag==="table"){
   let rows=[...node.querySelectorAll("tr")].map(tr=>[...tr.children].map(c=>inlineMarkdown(c).trim()));
   if(!rows.length)return "";
   let out="| "+rows[0].join(" | ")+" |\n| "+rows[0].map(()=> "---").join(" | ")+" |\n";
   rows.slice(1).forEach(r=>out+="| "+r.join(" | ")+" |\n");
   return "\n"+out+"\n";
  }
  return content;
 }
 function toMarkdown(n){let s=[...n.childNodes].map(inlineMarkdown).join("");return s.replace(/\n{3,}/g,"\n\n").trim()}
 function getRecords(){
  return findMessages().map((node,i)=>({node,index:i,role:roleOf(node,i),text:toMarkdown(node)})).filter(x=>x.text);
 }
 function closePanel(){document.getElementById("cs-panel")?.remove()}
 function openPanel(){
  closePanel();
  if(!document.getElementById(STYLE_ID)){let st=document.createElement("style");st.id=STYLE_ID;st.textContent=css;document.documentElement.append(st)}
  const panel=document.createElement("div");panel.id="cs-panel";
  panel.innerHTML=`<button class="cs-close" id="cs-close">✕</button><h3>Chat Saver</h3><div class="cs-muted">${SITE} · ${getRecords().length} detected messages</div><div><button id="cs-all">Select all</button><button id="cs-none">Clear</button><button id="cs-rescan">Rescan</button></div><div class="cs-list" id="cs-list"></div><div class="cs-actions"><button class="cs-primary" id="cs-md">Save Markdown</button><button class="cs-primary" id="cs-pdf">Save as PDF</button></div><div class="cs-status" id="cs-status">Select the full chat or individual messages. Exports are generated locally in your browser.</div>`;
  document.body.append(panel);
  panel.querySelector("#cs-close").onclick=closePanel;
  function render(){
   let rec=getRecords(),list=panel.querySelector("#cs-list");list.innerHTML="";
   rec.forEach(r=>{let l=document.createElement("label"),cb=document.createElement("input");cb.type="checkbox";cb.checked=true;cb.dataset.idx=r.index;let span=document.createElement("span");span.textContent=`${r.index+1}. ${r.role}: ${r.text.slice(0,105).replace(/\s+/g," ")}${r.text.length>105?"…":""}`;l.append(cb,span);list.append(l)});
   panel.querySelector(".cs-muted").textContent=`${SITE} · ${rec.length} detected messages`;
   panel.querySelector("#cs-status").textContent=rec.length? "Choose messages, then export. If the chat is still loading, use Rescan.":"No messages detected. Scroll the chat into view and press Rescan.";
  }
  function selected(){let rec=getRecords(),indices=[...panel.querySelectorAll('#cs-list input:checked')].map(x=>+x.dataset.idx);return rec.filter(r=>indices.includes(r.index))}
  function mdExport(){
   let rec=selected();if(!rec.length){alert("Select at least one message.");return}
   let title=cleanTitle(),md=`# ${title}\n\n> Exported from ${SITE} with Chat Saver · ${new Date().toLocaleString()}\n\n`+rec.map(r=>`## ${r.role}\n\n${r.text}`).join("\n\n---\n\n");
   download(new Blob([md],{type:"text/markdown;charset=utf-8"}),slug(title)+".md");
   panel.querySelector("#cs-status").textContent=`Markdown exported: ${rec.length} messages.`;
  }
  function pdfExport(){
   let rec=selected();if(!rec.length){alert("Select at least one message.");return}
   let title=cleanTitle(),content=rec.map(r=>`<article><h2>${escapeHtml(r.role)}</h2><div>${markdownHtml(r.text)}</div></article>`).join("");
   let html=`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>
   @page{size:A4;margin:18mm}body{font:11pt/1.55 Arial,sans-serif;color:#222}h1{font-size:22pt;border-bottom:2px solid #6556bf;padding-bottom:8px}h2{font-size:12pt;color:#5144ad;margin:20px 0 7px}article{break-inside:auto;margin-bottom:18px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f4f8;padding:10px;border-radius:6px;font:9pt Consolas,monospace}code{font-family:Consolas,monospace;background:#f1f1f5;padding:1px 3px}table{border-collapse:collapse;width:100%;font-size:9pt}td,th{border:1px solid #bbb;padding:6px}blockquote{border-left:3px solid #aaa;margin-left:0;padding-left:12px;color:#555}a{color:#333;overflow-wrap:anywhere}@media screen{body{max-width:850px;margin:35px auto;padding:30px;box-shadow:0 0 15px #ddd}}</style></head><body><h1>${escapeHtml(title)}</h1><p>Exported from ${SITE} · ${new Date().toLocaleString()}</p>${content}<script>window.onload=()=>setTimeout(()=>window.print(),400)<\/script></body></html>`;
   let blob=new Blob([html],{type:"text/html"}),url=URL.createObjectURL(blob),w=window.open(url,"_blank");
   if(!w){download(blob,slug(title)+"-print.html");panel.querySelector("#cs-status").textContent="Pop-up blocked. HTML print file downloaded; open it and choose Print → Save as PDF."}
   else panel.querySelector("#cs-status").textContent="Print dialog opened. Choose Save as PDF. PDF is generated locally; no server receives your chat.";
  }
  panel.querySelector("#cs-all").onclick=()=>{panel.querySelectorAll('#cs-list input').forEach(x=>x.checked=true)};
  panel.querySelector("#cs-none").onclick=()=>{panel.querySelectorAll('#cs-list input').forEach(x=>x.checked=false)};
  panel.querySelector("#cs-rescan").onclick=render;
  panel.querySelector("#cs-md").onclick=mdExport;
  panel.querySelector("#cs-pdf").onclick=pdfExport;
  render();
 }
 function markdownHtml(md){
  // Escape-first, conservative Markdown rendering for PDF. Keeps fenced code, tables, lists, headings.
  let s=escapeHtml(md);
  s=s.replace(/```([\s\S]*?)```/g,"<pre><code>$1</code></pre>");
  s=s.replace(/^###### (.*)$/gm,"<h6>$1</h6>").replace(/^##### (.*)$/gm,"<h5>$1</h5>").replace(/^#### (.*)$/gm,"<h4>$1</h4>").replace(/^### (.*)$/gm,"<h3>$1</h3>").replace(/^## (.*)$/gm,"<h2>$1</h2>").replace(/^# (.*)$/gm,"<h1>$1</h1>");
  s=s.replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>").replace(/\*(.*?)\*/g,"<em>$1</em>").replace(/`([^`]+)`/g,"<code>$1</code>");
  s=s.replace(/^\|(.+)\|$/gm,(line)=>"<tr>"+line.split("|").slice(1,-1).map(c=>"<td>"+c.trim()+"</td>").join("")+"</tr>");
  s=s.replace(/(?:<tr>.*<\/tr>\n?)+/g,m=>"<table>"+m+"</table>");
  s=s.replace(/^- (.*)$/gm,"<li>$1</li>").replace(/(?:<li>.*<\/li>\n?)+/g,m=>"<ul>"+m+"</ul>");
  s=s.split(/\n{2,}/).map(p=>/^(<h\d|<pre|<table|<ul|<li|<blockquote)/.test(p.trim())?p:"<p>"+p.replace(/\n/g,"<br>")+"</p>").join("\n");
  return s;
 }
 function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
 function slug(s){return s.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,70)||"ai-chat"}
 function download(blob,name){let a=document.createElement("a"),u=URL.createObjectURL(blob);a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1500)}
 chrome.runtime.onMessage.addListener(msg=>{if(msg.action==="OPEN_PANEL")openPanel();if(msg.action==="RESCAN"){if(document.getElementById("cs-panel"))openPanel();else openPanel()}});
})();