async function active(){let [t]=await chrome.tabs.query({active:true,currentWindow:true});return t}
async function send(action){let t=await active();if(!t?.id)return;try{await chrome.tabs.sendMessage(t.id,{action});document.getElementById("status").textContent="Chat Saver panel opened on this page."}catch(e){document.getElementById("status").textContent="Open a supported AI chat page and refresh it, then try again."}}
document.getElementById("open").onclick=()=>send("OPEN_PANEL");
document.getElementById("scan").onclick=()=>send("RESCAN");
